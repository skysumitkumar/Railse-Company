package companyName.workForceMgmt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkForceMgmtApplicationTests {

	@Test
	void contextLoads() {
	}

}
